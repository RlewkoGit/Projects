﻿namespace DND_roller
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.enemyTbxLvl = new System.Windows.Forms.TextBox();
            this.generateEnemyBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.HPlbl = new System.Windows.Forms.Label();
            this.STRlbl = new System.Windows.Forms.Label();
            this.Focuslbl = new System.Windows.Forms.Label();
            this.DEXlbl = new System.Windows.Forms.Label();
            this.COMPlbl = new System.Windows.Forms.Label();
            this.INTlbl = new System.Windows.Forms.Label();
            this.itemgenbtn = new System.Windows.Forms.Button();
            this.itemgentbx = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.epiccb = new System.Windows.Forms.CheckBox();
            this.legendarycb = new System.Windows.Forms.CheckBox();
            this.rarecb = new System.Windows.Forms.CheckBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.BPlbl = new System.Windows.Forms.Label();
            this.Braritylbl = new System.Windows.Forms.Label();
            this.typelbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enemy Star Level";
            // 
            // enemyTbxLvl
            // 
            this.enemyTbxLvl.Location = new System.Drawing.Point(12, 25);
            this.enemyTbxLvl.Name = "enemyTbxLvl";
            this.enemyTbxLvl.Size = new System.Drawing.Size(136, 20);
            this.enemyTbxLvl.TabIndex = 1;
            // 
            // generateEnemyBtn
            // 
            this.generateEnemyBtn.Location = new System.Drawing.Point(15, 51);
            this.generateEnemyBtn.Name = "generateEnemyBtn";
            this.generateEnemyBtn.Size = new System.Drawing.Size(133, 23);
            this.generateEnemyBtn.TabIndex = 2;
            this.generateEnemyBtn.Text = "Generate an Enemy";
            this.generateEnemyBtn.UseVisualStyleBackColor = true;
            this.generateEnemyBtn.Click += new System.EventHandler(this.generateEnemyBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Enemy Star Level : ";
            // 
            // HPlbl
            // 
            this.HPlbl.AutoSize = true;
            this.HPlbl.Location = new System.Drawing.Point(28, 111);
            this.HPlbl.Name = "HPlbl";
            this.HPlbl.Size = new System.Drawing.Size(31, 13);
            this.HPlbl.TabIndex = 4;
            this.HPlbl.Text = "HP : ";
            this.HPlbl.Click += new System.EventHandler(this.HP_Click);
            // 
            // STRlbl
            // 
            this.STRlbl.AutoSize = true;
            this.STRlbl.Location = new System.Drawing.Point(28, 140);
            this.STRlbl.Name = "STRlbl";
            this.STRlbl.Size = new System.Drawing.Size(38, 13);
            this.STRlbl.TabIndex = 5;
            this.STRlbl.Text = "STR : ";
            // 
            // Focuslbl
            // 
            this.Focuslbl.AutoSize = true;
            this.Focuslbl.Location = new System.Drawing.Point(28, 163);
            this.Focuslbl.Name = "Focuslbl";
            this.Focuslbl.Size = new System.Drawing.Size(45, 13);
            this.Focuslbl.TabIndex = 6;
            this.Focuslbl.Text = "Focus : ";
            // 
            // DEXlbl
            // 
            this.DEXlbl.AutoSize = true;
            this.DEXlbl.Location = new System.Drawing.Point(28, 185);
            this.DEXlbl.Name = "DEXlbl";
            this.DEXlbl.Size = new System.Drawing.Size(38, 13);
            this.DEXlbl.TabIndex = 7;
            this.DEXlbl.Text = "DEX : ";
            // 
            // COMPlbl
            // 
            this.COMPlbl.AutoSize = true;
            this.COMPlbl.Location = new System.Drawing.Point(28, 210);
            this.COMPlbl.Name = "COMPlbl";
            this.COMPlbl.Size = new System.Drawing.Size(44, 13);
            this.COMPlbl.TabIndex = 8;
            this.COMPlbl.Text = "COMP :";
            // 
            // INTlbl
            // 
            this.INTlbl.AutoSize = true;
            this.INTlbl.Location = new System.Drawing.Point(28, 235);
            this.INTlbl.Name = "INTlbl";
            this.INTlbl.Size = new System.Drawing.Size(34, 13);
            this.INTlbl.TabIndex = 9;
            this.INTlbl.Text = "INT : ";
            // 
            // itemgenbtn
            // 
            this.itemgenbtn.Location = new System.Drawing.Point(170, 130);
            this.itemgenbtn.Name = "itemgenbtn";
            this.itemgenbtn.Size = new System.Drawing.Size(133, 23);
            this.itemgenbtn.TabIndex = 12;
            this.itemgenbtn.Text = "Generate an Item";
            this.itemgenbtn.UseVisualStyleBackColor = true;
            this.itemgenbtn.Click += new System.EventHandler(this.itemgenbtn_Click);
            // 
            // itemgentbx
            // 
            this.itemgentbx.Location = new System.Drawing.Point(167, 25);
            this.itemgentbx.Name = "itemgentbx";
            this.itemgentbx.ReadOnly = true;
            this.itemgentbx.Size = new System.Drawing.Size(136, 20);
            this.itemgentbx.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(192, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Item Rarity Gen";
            // 
            // epiccb
            // 
            this.epiccb.AutoSize = true;
            this.epiccb.Location = new System.Drawing.Point(170, 84);
            this.epiccb.Name = "epiccb";
            this.epiccb.Size = new System.Drawing.Size(95, 17);
            this.epiccb.TabIndex = 13;
            this.epiccb.Text = "Can Drop Epic";
            this.epiccb.UseVisualStyleBackColor = true;
            // 
            // legendarycb
            // 
            this.legendarycb.AutoSize = true;
            this.legendarycb.Location = new System.Drawing.Point(170, 107);
            this.legendarycb.Name = "legendarycb";
            this.legendarycb.Size = new System.Drawing.Size(124, 17);
            this.legendarycb.TabIndex = 14;
            this.legendarycb.Text = "Can Drop Legendary";
            this.legendarycb.UseVisualStyleBackColor = true;
            // 
            // rarecb
            // 
            this.rarecb.AutoSize = true;
            this.rarecb.Location = new System.Drawing.Point(170, 61);
            this.rarecb.Name = "rarecb";
            this.rarecb.Size = new System.Drawing.Size(97, 17);
            this.rarecb.TabIndex = 15;
            this.rarecb.Text = "Can Drop Rare";
            this.rarecb.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(312, 61);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(91, 20);
            this.textBox1.TabIndex = 16;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(409, 61);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(91, 20);
            this.textBox2.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(347, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "Battle Damage Calculator";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(319, 97);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "Damage to : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(325, 43);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "Player 1 BP";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(426, 43);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "Player 2 BP";
            // 
            // BPlbl
            // 
            this.BPlbl.AutoSize = true;
            this.BPlbl.Location = new System.Drawing.Point(28, 258);
            this.BPlbl.Name = "BPlbl";
            this.BPlbl.Size = new System.Drawing.Size(30, 13);
            this.BPlbl.TabIndex = 22;
            this.BPlbl.Text = "BP : ";
            this.BPlbl.Click += new System.EventHandler(this.BPlbl_Click);
            // 
            // Braritylbl
            // 
            this.Braritylbl.AutoSize = true;
            this.Braritylbl.Location = new System.Drawing.Point(28, 284);
            this.Braritylbl.Name = "Braritylbl";
            this.Braritylbl.Size = new System.Drawing.Size(47, 13);
            this.Braritylbl.TabIndex = 23;
            this.Braritylbl.Text = "RARITY";
            // 
            // typelbl
            // 
            this.typelbl.AutoSize = true;
            this.typelbl.Location = new System.Drawing.Point(28, 308);
            this.typelbl.Name = "typelbl";
            this.typelbl.Size = new System.Drawing.Size(44, 13);
            this.typelbl.TabIndex = 24;
            this.typelbl.Text = "TYPE : ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 339);
            this.Controls.Add(this.typelbl);
            this.Controls.Add(this.Braritylbl);
            this.Controls.Add(this.BPlbl);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.rarecb);
            this.Controls.Add(this.legendarycb);
            this.Controls.Add(this.epiccb);
            this.Controls.Add(this.itemgenbtn);
            this.Controls.Add(this.itemgentbx);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.INTlbl);
            this.Controls.Add(this.COMPlbl);
            this.Controls.Add(this.DEXlbl);
            this.Controls.Add(this.Focuslbl);
            this.Controls.Add(this.STRlbl);
            this.Controls.Add(this.HPlbl);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.generateEnemyBtn);
            this.Controls.Add(this.enemyTbxLvl);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "DND GUIDEBOOK";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox enemyTbxLvl;
        private System.Windows.Forms.Button generateEnemyBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label HPlbl;
        private System.Windows.Forms.Label STRlbl;
        private System.Windows.Forms.Label Focuslbl;
        private System.Windows.Forms.Label DEXlbl;
        private System.Windows.Forms.Label COMPlbl;
        private System.Windows.Forms.Label INTlbl;
        private System.Windows.Forms.Button itemgenbtn;
        private System.Windows.Forms.TextBox itemgentbx;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox epiccb;
        private System.Windows.Forms.CheckBox legendarycb;
        private System.Windows.Forms.CheckBox rarecb;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label BPlbl;
        private System.Windows.Forms.Label Braritylbl;
        private System.Windows.Forms.Label typelbl;
    }
}

