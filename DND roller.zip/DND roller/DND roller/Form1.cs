﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DND_roller
{

    public partial class Form1 : Form
    {
        int starlvl = 0;
        int[] statArray = new int[6];

        int d20 = 20;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void generateEnemyBtn_Click(object sender, EventArgs e)
        {
            Random rnd1 = new Random();
            
            //  Random rnd2 = new Random();
            //  Random rnd3 = new Random();
            //  Random rnd4 = new Random();
            //  Random rnd5 = new Random();
            //  Random rnd6 = new Random();

            int hpgen = rnd1.Next(0, 20);
            // int strgen = rnd2.Next(0, 20);
            // int focusgen = rnd3.Next(0, 20);
            // int dexgen = rnd4.Next(0, 20);
            //  int compgen = rnd5.Next(0, 20);
            // int intgen = rnd6.Next(0, 20);

            for (int i = 0; i < 5; i++)
            {

                statArray[i] = rnd1.Next(hpgen);

            }


            //Level yennow

            int.TryParse(enemyTbxLvl.Text, out starlvl);
            label2.Text = $"Enemy Star Level : {starlvl}";


            //Stat Generation for enemies
            float HP = (20 * (starlvl + 1)) + statArray[0];
            float STR = (20 * (starlvl + 1)) + statArray[1];
            float Focus = (20 * (starlvl + 1)) + statArray[2];
            float DEX = (20 * (starlvl + 1)) + statArray[3];
            float COMP = (20 * (starlvl + 1)) + statArray[4];
            float INT = (20 * (starlvl + 1)) + statArray[5];

            HPlbl.Text = $"HP: {HP}";
            STRlbl.Text = $"STR: {STR}";
            Focuslbl.Text = $"Focus: {Focus}";
            DEXlbl.Text = $"DEX: {DEX}";
            COMPlbl.Text = $"COMP: {COMP}";
            INTlbl.Text = $"INT: {INT}";

            BPlbl.Text = $"BP: {(HP+STR+Focus+DEX)/100}";

            int color = rnd1.Next(0, 100);

            int type = rnd1.Next(0, 100);

            if (color < 50 )
            {
              Braritylbl.ForeColor = Color.Gray;
                Braritylbl.Text = "COMMON";
            } else if (color > 51 & color < 80 )
            {
                Braritylbl.ForeColor = Color.Green;
                Braritylbl.Text = "UNCOMMON";
            } else if (color > 81 & color < 90)
            {
                Braritylbl.ForeColor = Color.LightBlue;
                Braritylbl.Text = "RARE";
            } else if  (color > 91 & color < 95 )
            {
                Braritylbl.ForeColor = Color.Purple;
                Braritylbl.Text = "EPIC";
            } else if (color > 96 & color < 100)
            {
                Braritylbl.ForeColor = Color.Orange;
                Braritylbl.Text = "LEGENDARY";
            }
            
            if (type <= 15)
            {
                typelbl.Text = "FIRE";
                typelbl.ForeColor = Color.Gray;
            } else if (type >=16 & type <= 30)
            {
                typelbl.Text = "WATER";
                typelbl.ForeColor = Color.Gray;
            }
            else if (type >= 31 & type <= 45)
            {
                typelbl.Text = "EARTH";
                typelbl.ForeColor = Color.Gray;
            }
            else if (type >= 46 & type <= 60)
            {
                typelbl.Text = "WIND";
                typelbl.ForeColor = Color.Gray;
            }
            else if (type >= 61 & type <= 75)
            {
                typelbl.Text = "LIGHTNING";
                typelbl.ForeColor = Color.Gray;
            }
            else if (type >= 76 & type <= 80)
            {
                typelbl.Text = "FAIRY";
                typelbl.ForeColor = Color.Blue;
            }
            else if (type >= 81 & type <= 85)
            {
                typelbl.Text = "HOLY";
                typelbl.ForeColor = Color.Blue;
            }
            else if (type >= 86 & type <= 90)
            {
                typelbl.Text = "DARK";
                typelbl.ForeColor = Color.Blue;
            }
            else if (type == 91)
            {
                typelbl.Text = "SPACE";
                typelbl.ForeColor = Color.Gold;
            }
            else if (type == 92)
            {
                typelbl.Text = "TIME";
                typelbl.ForeColor = Color.Gold;
            }
            else if (type == 93)
            {
                typelbl.Text = "VOID";
                typelbl.ForeColor = Color.Gold;
            }
            else if (type == 94)
            {
                typelbl.Text = "CELESTIAL";
                typelbl.ForeColor = Color.Gold;
            }
            else if (type == 95)
            {
                typelbl.Text = "ELDRICH";
                typelbl.ForeColor = Color.Gold;
            }
            else if (type == 96)
            {
                typelbl.Text = "HEALING";
                typelbl.ForeColor = Color.Gold;
            }
            else if (type == 97)
            {
                typelbl.Text = "NECROMANCY";
                typelbl.ForeColor = Color.Gold;
            }
            else if (type == 98)
            {
                typelbl.Text = "BLOOD";
                typelbl.ForeColor = Color.Gold;
            }
            else if (type == 99)
            {
                typelbl.Text = "DRAGON";
                typelbl.ForeColor = Color.Gold;
            }
            else if (type == 100)
            {
                typelbl.Text = "CUSTOM";
                typelbl.ForeColor = Color.Gold;
            }





        }


        private void HP_Click(object sender, EventArgs e)
        {

        }

        private void itemgenbtn_Click(object sender, EventArgs e)
        {
            Random item = new Random();
            int rarity = item.Next(1, 1000);

            if (rarecb.Checked)
            {
                if (rarity <= 700)
                {
                    itemgentbx.Text = "Common";
                    itemgentbx.BackColor = Color.Gray;
                }
                else if (rarity >= 701 && rarity < 950)
                {
                    itemgentbx.Text = "Uncommon";
                    itemgentbx.BackColor = Color.Green;
                }
                else if (rarity >= 951)
                {
                    itemgentbx.Text = "Rare";
                    itemgentbx.BackColor = Color.LightBlue;
                }

                if (epiccb.Checked)
                {
                    if (rarity <= 700)
                    {
                        itemgentbx.Text = "Common";
                        itemgentbx.BackColor = Color.Gray;
                    }
                    else if (rarity >= 701 && rarity < 950)
                    {
                        itemgentbx.Text = "Uncommon";
                        itemgentbx.BackColor = Color.Green;
                    }
                    else if (rarity >= 951 && rarity < 980)
                    {
                        itemgentbx.Text = "Rare";
                        itemgentbx.BackColor = Color.LightBlue;
                    }
                    else if (rarity >= 981)
                    {
                        itemgentbx.Text = "Epic";
                        itemgentbx.BackColor = Color.Purple;
                    }


                    if (legendarycb.Checked)
                    {
                        if (epiccb.Checked)
                        {
                            if (rarity <= 700)
                            {
                                itemgentbx.Text = "Common";
                                itemgentbx.BackColor = Color.Gray;
                            }
                            else if (rarity >= 701 && rarity < 950)
                            {
                                itemgentbx.Text = "Uncommon";
                                itemgentbx.BackColor = Color.Green;
                            }
                            else if (rarity >= 951 && rarity < 980)
                            {
                                itemgentbx.Text = "Rare";
                                itemgentbx.BackColor = Color.LightBlue;
                            }
                            else if (rarity >= 981 && rarity < 993)
                            {
                                itemgentbx.Text = "Epic";
                                itemgentbx.BackColor = Color.Purple;
                            }
                            else if (rarity >= 994)
                            {
                                itemgentbx.Text = "Legendary";
                                itemgentbx.BackColor = Color.Orange;
                            }
                        }

                    }
                }
            }


            else
            {

                if (rarity <= 700)
                {
                    itemgentbx.Text = "Common";
                    itemgentbx.BackColor = Color.Gray;
                }
                else if (rarity >= 701)
                {
                    itemgentbx.Text = "Uncommon";
                    itemgentbx.BackColor = Color.Green;
                }

            }
        }

        private void BPlbl_Click(object sender, EventArgs e)
        {

        }
    }
}
        
    



